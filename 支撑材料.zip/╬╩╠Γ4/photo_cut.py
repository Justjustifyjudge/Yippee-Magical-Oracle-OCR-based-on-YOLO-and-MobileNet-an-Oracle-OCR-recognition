import os
import cv2

def crop_images(image_folder, annotation_folder, destination_folder):
    # 获取图片文件夹中的文件列表
    image_files = os.listdir(image_folder)

    # 遍历图片文件夹中的每个文件
    for image_file in image_files:
        image_name, _ = os.path.splitext(image_file)
        # 构建对应的验证框文件路径
        annotation_file_path = os.path.join(annotation_folder, image_name + '.txt')

        # 读取对应的图片
        image_path = os.path.join(image_folder, image_file)
        if not os.path.isfile(image_path):
            continue
        image = cv2.imread(image_path)

        # 如果对应的验证框文件不存在，则跳过
        if not os.path.isfile(annotation_file_path):
            continue

        # 读取验证框文件中的信息
        with open(annotation_file_path, 'r') as f:
            lines = f.readlines()

        i = 0
        # 遍历每行信息
        for line in lines:
            # 解析边界框信息
            class_id, x_center, y_center, width, height = map(float, line.strip().split())

            # 计算边界框在图片中的坐标
            image_height, image_width, _ = image.shape
            x1 = int((x_center - width / 2) * image_width)
            y1 = int((y_center - height / 2) * image_height)
            x2 = int((x_center + width / 2) * image_width)
            y2 = int((y_center + height / 2) * image_height)

            # 切割图片
            cropped_image = image[y1:y2, x1:x2]

            # 保存切割后的图片到目标文件夹
            destination_path = os.path.join(destination_folder, f"{image_name}_{int(i)}.jpg")
            cv2.imwrite(destination_path, cropped_image)
            i += 1

if __name__ == "__main__":
    image_folder = r"C:\Users\linyiwu\Desktop\Mathorcup2024\testset"  # 图片文件夹路径
    annotation_folder = r"C:\Users\linyiwu\Desktop\Mathorcup2024\labels"  # 验证框文件夹路径
    destination_folder = r"C:\Users\linyiwu\Desktop\Mathorcup2024\cut_photos"  # 目标文件夹路径

    crop_images(image_folder, annotation_folder, destination_folder)
