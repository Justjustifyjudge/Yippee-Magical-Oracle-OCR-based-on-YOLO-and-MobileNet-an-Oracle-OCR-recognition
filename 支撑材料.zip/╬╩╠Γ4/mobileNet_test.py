from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D
from tensorflow.keras.applications import MobileNet
from tensorflow.keras.models import Sequential
test_datagen = ImageDataGenerator(rescale=1./255)  # 确保与训练时的数据预处理相同
test_generator = test_datagen.flow_from_directory(
        r'C:\Users\linyiwu\Desktop\Mathorcup2024\cut_photos_bmp',
        target_size=(224, 224),  # 模型输入的图像尺寸
        batch_size=1,
        class_mode=None,  # 设置为None，表示不返回标签
        shuffle=False)  # 不要打乱顺序，保持与文件名对应

from tensorflow.keras.models import load_model

# 载入模型
loaded_model = load_model(r'C:\Users\linyiwu\Desktop\Mathorcup2024\mobilenet_model.h5')
# # 重新编译模型
# loaded_model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# # 预测测试集
# predictions = loaded_model.predict(test_generator, steps=len(test_generator), verbose=1)

# # 将预测结果保存到文件
# import numpy as np

# np.save(r'C:\Users\linyiwu\Desktop\Mathorcup2024\test_predictions.npy', predictions)

