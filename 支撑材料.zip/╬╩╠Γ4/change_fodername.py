import os

# 定义字典文件路径
dictionary_path = r"C:\Users\linyiwu\Desktop\Mathorcup2024\甲骨文智能识别中原始拓片单字自动分割与识别研究\task4\class_dict.json"

# 读取字典文件
with open(dictionary_path, "r", encoding="utf-8") as f:
    dictionary = eval(f.read())

# 源文件夹路径
src_folder = r"C:\Users\linyiwu\Desktop\Mathorcup2024\trainset"

# 遍历源文件夹中的所有文件夹
for folder_name in os.listdir(src_folder):
    # 检查是否为文件夹
    folder_path = os.path.join(src_folder, folder_name)
    if os.path.isdir(folder_path):
        # 获取文件夹在字典中的序号
        folder_index = dictionary.get(folder_name)
        if folder_index is not None:
            # 构造新的文件夹名字
            new_folder_name = str(folder_index)
            # 重命名文件夹
            os.rename(folder_path, os.path.join(src_folder, new_folder_name))
            print(f"Renamed folder {folder_name} to {new_folder_name}")
        else:
            print(f"Folder {folder_name} not found in dictionary")
