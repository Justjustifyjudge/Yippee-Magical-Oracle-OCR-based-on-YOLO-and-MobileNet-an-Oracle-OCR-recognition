import numpy as np
import pandas as pd
import os
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications import MobileNetV3Small
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.preprocessing.image import img_to_array, load_img

train_data_dir = r'C:\Users\linyiwu\Desktop\Mathorcup2024\trainset'
test_data_dir = r'C:\Users\linyiwu\Desktop\Mathorcup2024\cut_photos_bmp'
output_csv = 'predictions.csv'
input_shape = (224, 224)
num_classes = 76  # 76个类别
batch_size = 16

# 定义ImageDataGenerator
datagen = ImageDataGenerator(
    rescale=1./255,
    validation_split=0.2  # 设置验证集比例为 20%
)

# 从目录中加载数据并划分训练集和验证集
train_generator = datagen.flow_from_directory(
    r'C:\Users\linyiwu\Desktop\Mathorcup2024\trainset',  # 替换为你的数据集目录
    target_size=(224, 224),
    batch_size=batch_size,
    class_mode='categorical',
    subset='training'  # 指定加载训练集数据
)

validation_generator = datagen.flow_from_directory(
    r'C:\Users\linyiwu\Desktop\Mathorcup2024\trainset',  # 替换为你的数据集目录
    target_size=(224, 224),
    batch_size=batch_size,
    class_mode='categorical',
    subset='validation'  # 指定加载验证集数据
)

test_datagen = ImageDataGenerator(rescale=1. / 255)

test_generator = test_datagen.flow_from_directory(
    test_data_dir,
    target_size=input_shape,
    batch_size=batch_size,
    class_mode=None,
    shuffle=False
)


base_model = MobileNetV3Small(weights='imagenet', include_top=False, input_shape=(224, 224, 3))

x = base_model.output
x = GlobalAveragePooling2D()(x)
x = Dense(1024, activation='relu')(x)
predictions = Dense(num_classes, activation='softmax')(x)

model = Model(inputs=base_model.input, outputs=predictions)

for layer in base_model.layers:
    layer.trainable = False

model.compile(optimizer=Adam(), loss='categorical_crossentropy', metrics=['accuracy'])

model.fit(train_generator, epochs=10, validation_data=validation_generator)

# test_preds = model.predict(test_generator, verbose=1)
# predicted_class_indices = np.argmax(test_preds, axis=1)

# labels = (train_generator.class_indices)
# labels = dict((v, k) for k, v in labels.items())
# predictions = [labels[k] for k in predicted_class_indices]

# filenames = test_generator.filenames
# results = pd.DataFrame({"Filename": filenames, "Predictions": predictions})
# results.to_csv(output_csv, index=False)

# 加载并预测单个文件夹中的图片
images_folder = os.listdir(test_data_dir)
predictions_list = []
for img_name in images_folder:
    img_path = os.path.join(test_data_dir, img_name)
    img = load_img(img_path, target_size=input_shape)
    img_array = img_to_array(img)
    img_array = np.expand_dims(img_array, axis=0)
    img_array /= 255.0  # 归一化
    pred = model.predict(img_array)
    predicted_class = np.argmax(pred, axis=1)[0]
    predictions_list.append((img_name, predicted_class))

# 保存预测结果到CSV文件
results = pd.DataFrame(predictions_list, columns=["Filename", "Predicted_Class_Index"])
results.to_csv(output_csv, index=False)
