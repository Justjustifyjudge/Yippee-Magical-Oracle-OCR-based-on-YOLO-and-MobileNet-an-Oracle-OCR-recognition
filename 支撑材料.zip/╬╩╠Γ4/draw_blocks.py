import os
import cv2
import pandas as pd
from PIL import ImageFont,ImageDraw,Image
import numpy as np

def read_csv(csv_file):
    # 读取CSV文件，返回文件名、行号和类别名的对应关系
    df = pd.read_csv(csv_file)
    return df.values.tolist()

def read_txt(txt_file, row_number):
    # 从TXT文件中获取指定行号的验证框信息
    with open(txt_file, 'r') as f:
        lines = f.readlines()
        line = lines[int(row_number)]  # 行号从0开始
        # 解析YOLO格式的验证框信息（假设格式为：class_name x_center y_center width height）
        class_name, x_center, y_center, width, height = line.strip().split()
        return class_name, float(x_center), float(y_center), float(width), float(height)

def draw_bbox(image, class_name, x_center, y_center, width_chuan, height_chuan, output_folder, filename):
    # Convert normalized coordinates to pixel coordinates
    height, width, _ = image.shape
    x_center_pixel = int(x_center * width)
    y_center_pixel = int(y_center * height)
    width_pixel = int(width * width_chuan)
    height_pixel = int(height * height_chuan)

    # Calculate bounding box coordinates
    x_min = x_center_pixel - (width_pixel // 2)
    y_min = y_center_pixel - (height_pixel // 2)
    x_max = x_center_pixel + (width_pixel // 2)
    y_max = y_center_pixel + (height_pixel // 2)

    # Draw bounding box
    cv2.rectangle(image, (x_min, y_min), (x_max, y_max), (0, 0, 255), 2)

    # Draw class name using PIL
    font_path = "simsun.ttc"
    font_size = 30
    font_color = (255, 0, 0)
    font = ImageFont.truetype(font_path, font_size)
    img_pil = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(img_pil)
    draw.text((x_min, y_min - font_size), class_name, font=font, fill=font_color)

    # Convert PIL image back to OpenCV format and save
    image_with_text = cv2.cvtColor(np.array(img_pil), cv2.COLOR_RGB2BGR)
    cv2.imwrite(output_folder + '/' + filename + '.jpg', image_with_text)

def main():
    src_folder = r'C:\Users\linyiwu\Desktop\Mathorcup2024\src_data\labels'  # 存放txt文件的文件夹
    photo_folder = r'C:\Users\linyiwu\Desktop\Mathorcup2024\src_data\testset'  # 存放图片的文件夹
    csv_file = 'predictions.csv'  # CSV文件名
    output_foder = r'C:\Users\linyiwu\Desktop\Mathorcup2024\src_data\testset'  # 输出图片的文件夹
    data = read_csv(csv_file)

    for filename, class_number, class_name in data:
        filename, row_number_and_ext = filename.split('_')
        row_number = row_number_and_ext.split('.')[0]
        txt_file = os.path.join(src_folder, filename + '.txt')
        photo_file = os.path.join(photo_folder, filename + '.jpg')
        # print(f"Processing {filename}")
        # print(f"Row_number: {row_number}")
        if os.path.exists(txt_file) and os.path.exists(photo_file):
            image = cv2.imread(photo_file)
            _, x_center, y_center, width, height = read_txt(txt_file, row_number)
            # print(f"x_center: {x_center}, y_center: {y_center}, width: {width}, height: {height}")
            draw_bbox(image, class_name, x_center, y_center, width, height, output_foder, filename)
            # cv2.imshow(image)
            
            # print(f"Processed {filename}")

if __name__ == "__main__":
    main()
