import os
from PIL import Image
import random
import json

# 存储类别名称和对应的分类编号
class_dict = {}

# 遍历文件夹
base_path = "甲骨文智能识别中原始拓片单字自动分割与识别研究/4_Recognize/训练集"  # 修改为你的数据集文件夹路径
class_id = 1  # 从1开始编号类别
for folder_name in os.listdir(base_path):
    folder_path = os.path.join(base_path, folder_name)
    if os.path.isdir(folder_path):
        class_dict[folder_name] = class_id
        class_id += 1

# 打印类别名称和对应的分类编号
for class_name, class_id in class_dict.items():
    print(f"Class Name: {class_name}, Class ID: {class_id}")

# 这里可以将class_dict保存到文件中，以便后续使用
output_file = "甲骨文智能识别中原始拓片单字自动分割与识别研究/task4/class_dict.json"  # 修改为你要保存的文件路径
with open(output_file, "w") as f:
    json.dump(class_dict, f)

print(f"Class dictionary saved to {output_file}")

# 定义划分比例
train_ratio = 0.8  # 80% 的数据作为训练集
test_ratio = 1.0 - train_ratio  # 剩余的数据作为测试集

# 遍历文件夹
base_path = "甲骨文智能识别中原始拓片单字自动分割与识别研究/4_Recognize/训练集"  # 修改为你的数据集文件夹路径
train_output_path = "甲骨文智能识别中原始拓片单字自动分割与识别研究/task4/train"  # 修改为你的训练集输出文件夹路径
test_output_path = "甲骨文智能识别中原始拓片单字自动分割与识别研究/task4/test"  # 修改为你的测试集输出文件夹路径

# 创建输出文件夹
os.makedirs(train_output_path, exist_ok=True)
os.makedirs(test_output_path, exist_ok=True)

# 存储图像数据和对应的分类编号
data = []

for folder_name in os.listdir(base_path):
    folder_path = os.path.join(base_path, folder_name)
    if os.path.isdir(folder_path):
        class_name = folder_name
        class_id = class_dict.get(class_name, -1)  # 获取类别编号，如果不存在则为-1
        if class_id != -1:
            images = []
            for filename in os.listdir(folder_path):
                image_path = os.path.join(folder_path, filename)
                if filename.endswith(".jpg") or filename.endswith(".png") or filename.endswith(".bmp"):  # 根据你的图片格式修改
                    try:
                        image = Image.open(image_path)
                        images.append((image, class_id, filename))
                    except Exception as e:
                        print(f"Error processing image {image_path}: {e}")
            # 打乱顺序
            random.shuffle(images)
            # 划分数据
            train_size = int(len(images) * train_ratio)
            train_data = images[:train_size]
            test_data = images[train_size:]
            # 将数据添加到总体数据集中
            data.extend(train_data)
            data.extend(test_data)
            # 将数据保存到对应的文件夹中
            for img, img_class, img_filename in train_data:
                img_name = f"{class_id}_{img_filename}"
                img_path = os.path.join(train_output_path, img_name)
                img.save(img_path)
            for img, img_class, img_filename in test_data:
                img_name = f"{class_id}_{img_filename}"
                img_path = os.path.join(test_output_path, img_name)
                img.save(img_path)

print("数据集划分完成并保存到对应文件夹中")