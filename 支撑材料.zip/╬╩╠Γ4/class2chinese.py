import pandas as pd
import json

# 读取字典文件
with open(r'甲骨文智能识别中原始拓片单字自动分割与识别研究\task4\class_dict.json', 'r') as f:
    class_dict = json.load(f)

# 将字典的键值对反转，以便通过类别编号查找中文字
reversed_class_dict = {value: key for key, value in class_dict.items()}

# 读取csv文件
csv_file = 'predictions.csv'
df = pd.read_csv(csv_file)

# 遍历csv文件中的每一行
for index, row in df.iterrows():
    # 获取类别编号
    class_id = row['Predicted_Class_Index']

    # 获取类别编号对应的中文字
    if class_id in reversed_class_dict:
        class_name = reversed_class_dict[class_id]

    # 将类别名写入csv文件
    df.at[index, 'class_name'] = class_name

# 保存修改后的csv文件
df.to_csv(csv_file, index=False)