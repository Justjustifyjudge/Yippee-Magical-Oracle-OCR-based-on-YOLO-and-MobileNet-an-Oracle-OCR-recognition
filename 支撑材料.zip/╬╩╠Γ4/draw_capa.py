import pandas as pd
import matplotlib.pyplot as plt

# 从文本文件读取数据
data = pd.read_csv(r'task4性能参数.txt', delimiter='\s+')

# 绘制训练准确率和验证准确率的折线图
plt.figure(figsize=(10, 6))
plt.plot(data.index, data['Train_Accuracy'], label='Train Accuracy', marker='o')
plt.plot(data.index, data['Validation_Accuracy'], label='Validation Accuracy', marker='x')
plt.title('Training and Validation Accuracy Over Epochs')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()
plt.grid(True)
plt.show()

# 绘制训练损失和验证损失的折线图
plt.figure(figsize=(10, 6))
plt.plot(data.index, data['Train_Loss'], label='Train Loss', marker='o')
plt.plot(data.index, data['Validation_Loss'], label='Validation Loss', marker='x')
plt.title('Training and Validation Loss Over Epochs')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()
plt.grid(True)
plt.show()
