import os
from PIL import Image

# 定义源文件夹和目标文件夹的路径
source_folder = r'C:\Users\linyiwu\Desktop\Mathorcup2024\cut_photos'  # 替换为实际的源文件夹路径
destination_folder = r'C:\Users\linyiwu\Desktop\Mathorcup2024\cut_photos_bmp'  # 替换为实际的目标文件夹路径

# 创建目标文件夹（如果不存在）
if not os.path.exists(destination_folder):
    os.makedirs(destination_folder)

# 获取源文件夹中的所有.jpg文件
jpg_files = [file for file in os.listdir(source_folder) if file.lower().endswith('.jpg')]

# 遍历每个.jpg文件并转换为.bmp格式保存到目标文件夹
for jpg_file in jpg_files:
    # 构建完整的源文件路径和目标文件路径
    jpg_path = os.path.join(source_folder, jpg_file)
    bmp_file = os.path.splitext(jpg_file)[0] + '.bmp'
    bmp_path = os.path.join(destination_folder, bmp_file)

    # 打开.jpg文件并转换为.bmp格式并保存
    with Image.open(jpg_path) as img:
        img.save(bmp_path)

print('转换完成！')
