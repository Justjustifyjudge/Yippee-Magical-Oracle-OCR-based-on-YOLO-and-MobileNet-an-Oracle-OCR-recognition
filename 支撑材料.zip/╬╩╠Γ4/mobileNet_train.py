import os
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications import MobileNet
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D

img_width, img_height = 224, 224
batch_size = 16

# 定义ImageDataGenerator
datagen = ImageDataGenerator(
    rescale=1./255,
    validation_split=0.2  # 设置验证集比例为 20%
)

# 从目录中加载数据并划分训练集和验证集
train_generator = datagen.flow_from_directory(
    r'C:\Users\linyiwu\Desktop\Mathorcup2024\trainset',  # 替换为你的数据集目录
    target_size=(img_height, img_width),
    batch_size=batch_size,
    class_mode='categorical',
    subset='training'  # 指定加载训练集数据
)

validation_generator = datagen.flow_from_directory(
    r'C:\Users\linyiwu\Desktop\Mathorcup2024\trainset',  # 替换为你的数据集目录
    target_size=(img_height, img_width),
    batch_size=batch_size,
    class_mode='categorical',
    subset='validation'  # 指定加载验证集数据
)


base_model = MobileNet(weights='imagenet', include_top=False)
model = Sequential()
model.add(base_model)
model.add(GlobalAveragePooling2D())
model.add(Dense(256, activation='relu'))
model.add(Dense(train_generator.num_classes, activation='softmax'))

model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

epochs = 10
model.fit(
    train_generator,
    steps_per_epoch=train_generator.samples // batch_size,
    epochs=epochs,
    validation_data=validation_generator,
    validation_steps=validation_generator.samples // batch_size)

model.save('mobilenet_model.h5')

# from keras.models import load_model

# loaded_model = load_model('mobilenet_model.h5')

# # 继续训练加载的模型
# loaded_model.fit(
#     train_generator,
#     steps_per_epoch=train_generator.samples // batch_size,
#     epochs=epochs,
#     validation_data=validation_generator,
#     validation_steps=validation_generator.samples // batch_size)
