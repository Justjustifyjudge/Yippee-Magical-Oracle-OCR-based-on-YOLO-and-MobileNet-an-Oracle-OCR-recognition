from PIL import Image
import os

def convert_bmp_to_jpg(input_folder, output_folder):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    for file_name in os.listdir(input_folder):
        if file_name.endswith('.bmp'):
            input_path = os.path.join(input_folder, file_name)
            output_path = os.path.join(output_folder, file_name.replace('.bmp', '.jpg'))

            img = Image.open(input_path)
            img.convert('RGB').save(output_path, 'JPEG')
            print(f"Converted {input_path} to {output_path}")

if __name__ == "__main__":
    input_folder = "甲骨文智能识别中原始拓片单字自动分割与识别研究/task4/train"  # 指定包含 .bmp 文件的文件夹路径
    output_folder = "甲骨文智能识别中原始拓片单字自动分割与识别研究/task4/train_jpg"  # 指定保存 .jpg 文件的文件夹路径

    convert_bmp_to_jpg(input_folder, output_folder)