# from ultralytics import YOLO

# model =YOLO("best.pt",task="detect")


# result=model(source=r'D:\PycharmProjects\2024mathorcup\B题\dataset\test\images\020027.jpg',save=True,save_txt=True)
# # 最后的标签填到result表中是浮点数，但是要四舍五入掉小数，因为label标签是图像上方框左上角和右下角的坐标，是整数

import os
from ultralytics import YOLO
from os import listdir
from os.path import isfile, join
from PIL import Image

# 文件夹路径
folder_path = r"D:\PycharmProjects\2024mathorcup\B题\dataset\test\images"

# 获取文件夹中所有图片文件名
image_files = [f for f in listdir(folder_path) if isfile(join(folder_path, f)) and f.lower().endswith(('.jpg'))]

# 加载模型
model = YOLO(r"D:\PycharmProjects\2024mathorcup\B题\问题2&3\best.pt", task="detect")

# # 创建保存结果的文件夹
# output_folder = "output_results"
# if not os.path.exists(output_folder):
#     os.makedirs(output_folder)

# 遍历图片并进行检测
image_files = [join(folder_path, image_file) for image_file in image_files]

results = model(image_files,save=True,save_txt=True)

for r in results:
    print(r.boxes)
