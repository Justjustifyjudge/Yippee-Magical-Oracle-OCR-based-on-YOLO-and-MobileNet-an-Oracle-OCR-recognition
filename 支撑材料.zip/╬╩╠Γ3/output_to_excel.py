import os
from openpyxl import Workbook, load_workbook

# 指定文件夹路径和Excel文件路径,要填绝对路径，否则excel写不进去
folder_path = r'D:\PycharmProjects\2024mathorcup\B题\runs\detect\predict\output'
excel_path = r'D:\PycharmProjects\2024mathorcup\B题\问题2&3\Test_results.xlsx'

# 加载现有的Excel文件
wb = load_workbook(excel_path)
ws = wb.active

# 指定开始写入的行数
start_row = 3

# 遍历文件夹中的所有txt文件
for file_name in os.listdir(folder_path):
    if file_name.endswith('.txt'):
        file_path = os.path.join(folder_path, file_name)
        with open(file_path, 'r', encoding='utf-8') as file:
            # 读取文件内容的第一行
            first_line = file.readline().strip()
            # # 将文件名和第一行内容写入Excel的指定单元格位置
            # ws.cell(row=start_row, column=2, value=file_name)
            ws.cell(row=start_row, column=2, value=first_line)
            # 移动到下一行
            start_row += 1

# 保存Excel文件
wb.save(excel_path)