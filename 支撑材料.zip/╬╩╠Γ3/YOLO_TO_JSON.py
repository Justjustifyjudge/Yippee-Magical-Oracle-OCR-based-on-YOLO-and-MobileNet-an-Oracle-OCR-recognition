import os
import json
from PIL import Image
import shutil

def get_image_size(image_path):
    with Image.open(image_path) as img:
        width, height = img.size
    return width, height

def convert_yolo_to_absolute(yolo_labels_file, image_width, image_height):
    with open(yolo_labels_file, 'r') as f:
        lines = f.readlines()

    converted_labels = []
    for line in lines:
        class_id, x_center, y_center, bbox_width, bbox_height = map(float, line.strip().split())
        
        # # 将相对坐标转换为绝对坐标
        # x_min = max(0, (x_center - bbox_width / 2) * image_width)
        # y_min = max(0, (y_center - bbox_height / 2) * image_height)
        # x_max = min(image_width, (x_center + bbox_width / 2) * image_width)
        # y_max = min(image_height, (y_center + bbox_height / 2) * image_height)

        # 将相对坐标转换为绝对坐标，并四舍五入保留为浮点数但小数部分为0
        x_min = round(max(0, (x_center - bbox_width / 2) * image_width), 0)
        y_min = round(max(0, (y_center - bbox_height / 2) * image_height), 0)
        x_max = round(min(image_width, (x_center + bbox_width / 2) * image_width), 0)
        y_max = round(min(image_height, (y_center + bbox_height / 2) * image_height), 0)
        
        
        converted_labels.append((x_min, y_min, x_max, y_max, class_id))

    return converted_labels

def process_folder(input_folder, output_folder, images_folder):
    # 确保输出文件夹存在，如果不存在则创建
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # 获取输入文件夹中所有的标签文件
    label_files = [f for f in os.listdir(input_folder) if f.endswith('.txt')]
    
    for label_file in label_files:
        # 获取当前标签文件的路径
        label_file_path = os.path.join(input_folder, label_file)
        
        # 从标签文件名中提取对应的图像文件名（假设标签文件名和图像文件名一一对应）
        image_file_name = os.path.splitext(label_file)[0] + '.jpg'
        
        # 根据图像文件名获取图像的宽度和高度
        image_file_path = os.path.join(images_folder, image_file_name)
        image_width, image_height = get_image_size(image_file_path)
        
        # 转换标签文件
        converted_labels = convert_yolo_to_absolute(label_file_path, image_width, image_height)
        
        # 写入转换后的标签到输出文件夹中
        output_file_path = os.path.join(output_folder, label_file)
        with open(output_file_path, 'w') as f:
            for label in converted_labels:
                f.write(' '.join(map(str, label)) + '\n')

# 示例用法
input_folder = r'D:\PycharmProjects\2024mathorcup\B题\runs\detect\predict\labels'  # 输入文件夹路径，包含所有的标签文件
output_folder = r'D:\PycharmProjects\2024mathorcup\B题\runs\detect\predict\jsons_result'  # 输出文件夹路径，用于存放转换后的标签文件
images_folder = r'D:\PycharmProjects\2024mathorcup\B题\runs\detect\predict\images'  # 图片文件夹路径，包含所有的图像文件

process_folder(input_folder, output_folder, images_folder)