import os

def convert_labels(input_folder, output_folder):
    # 确保输出文件夹存在，如果不存在则创建
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # 遍历输入文件夹中的所有文件
    for filename in os.listdir(input_folder):
        if filename.endswith(".txt"):  # 只处理txt文件
            input_filepath = os.path.join(input_folder, filename)
            output_filepath = os.path.join(output_folder, filename)

            # 打开输入文件并读取内容
            with open(input_filepath, 'r') as f:
                lines = f.readlines()

            # 转换每一行的内容
            converted_lines = []
            for line in lines:
                # 移除换行符并将数字字符串转换为浮点数
                numbers = [float(num) for num in line.strip().split()]
                # 将列表转换为字符串形式
                converted_line = "[" + ", ".join(str(num) for num in numbers) + "]"
                converted_lines.append(converted_line)

            # 将转换后的内容写入输出文件
            with open(output_filepath, 'w') as f:
                f.write(", ".join(converted_lines))

            print(f"Converted {filename}")

# 输入文件夹路径和输出文件夹路径
input_folder = r"D:\PycharmProjects\2024mathorcup\B题\runs\detect\predict\jsons_result"
output_folder = r"D:\PycharmProjects\2024mathorcup\B题\runs\detect\predict\output"

# 调用函数进行批量处理
convert_labels(input_folder, output_folder)