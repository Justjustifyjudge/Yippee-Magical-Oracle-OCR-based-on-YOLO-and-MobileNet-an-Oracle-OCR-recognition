import cv2
import numpy as np
import matplotlib.pyplot as plt

# 加载原始图像
image_path = r'./b03507.jpg'
image = cv2.imread(image_path)

# 创建一个空列表来存储增强后的图像
augmented_images = []

# 色彩变换
augmented_image = cv2.cvtColor(image, cv2.COLOR_BGR2HLS)
augmented_images.append(augmented_image)

# 缩放
scaled_image = cv2.resize(image,None, fx=0.5, fy=0.7, interpolation=cv2.INTER_LINEAR)
augmented_images.append(scaled_image)

# 亮度变化
brightened_image = cv2.convertScaleAbs(image, alpha=1.5, beta=50)
augmented_images.append(brightened_image)

# 添加高斯噪声
noise = np.random.normal(0, 20, image.shape).astype('uint8')
noisy_image = cv2.add(image, noise)
augmented_images.append(noisy_image)

# 高斯模糊
blurred_image = cv2.GaussianBlur(image, (5, 5), 0)
augmented_images.append(blurred_image)

# 显示原始图像和增强后的图像
plt.figure(figsize=(15, 10))

# 显示原始图像
plt.subplot(2, 3, 1)
plt.title('Original Image')
plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
plt.axis('off')

# 显示数据增强后的图像
for i, img in enumerate(augmented_images, start=2):
    plt.subplot(2, 3, i)
    plt.title(f'Augmented Image {i-1}')
    plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    plt.axis('off')

plt.show()