import cv2
from skimage.feature import graycomatrix, graycoprops
import matplotlib.pyplot as plt

# 1. 读取原始图像
image = cv2.imread('image2.jpg')

# 2. 灰度化
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

image_bil = cv2.bilateralFilter(gray_image, 9, 25, 10, cv2.BORDER_DEFAULT)  # 双边滤波
image_median = cv2.medianBlur(image_bil, 3)  # 中值滤波

binary = cv2.adaptiveThreshold(  # 自适应阈值二值化 adaptive_threshold
    image_median,
    255,
    cv2.ADAPTIVE_THRESH_GAUSSIAN_C, \
    cv2.THRESH_BINARY, 11, 10)

# 边缘检测
image_canny = cv2.Canny(binary, 100, 400, 5)



# 特征提取
# 1. 形状特征 - 计算图像的Hu矩
moments = cv2.moments(binary)
hu_moments = cv2.HuMoments(moments)

# 2. 纹理特征 - 灰度共生矩阵和对比度
glcm = graycomatrix(image_median, distances=[1], angles=[0], symmetric=True, normed=True)
contrast = graycoprops(glcm, 'contrast')[0, 0]


# 打印提取的特征
print(f'Hu Invariants:\n {hu_moments}')
print(f'Contrast: {contrast}')


# 可视化结果
# cv2.imshow("Original Image", image)
# cv2.imshow("Gray Image", gray_image)
# cv2.imshow("image_bil", image_bil)
# cv2.imshow("image_median", image_median)
# cv2.imshow("binary", binary)
# cv2.imshow("Edges", image_canny)

# 创建一个2x3的子图布局
plt.figure(figsize=(12, 8))

# 显示原始图像
plt.subplot(2, 3, 1)
plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
plt.title("Original Image")
plt.axis('off')

# 显示灰度图像
plt.subplot(2, 3, 2)
plt.imshow(gray_image, cmap='gray')
plt.title("Gray Image")
plt.axis('off')

# 显示双边滤波后的图像
plt.subplot(2, 3, 3)
plt.imshow(cv2.cvtColor(image_bil, cv2.COLOR_BGR2RGB))
plt.title("Bilateral Filter")
plt.axis('off')

# 显示中值滤波后的图像
plt.subplot(2, 3, 4)
plt.imshow(cv2.cvtColor(image_median, cv2.COLOR_BGR2RGB))
plt.title("Median Filter")
plt.axis('off')

# 显示二值化后的图像
plt.subplot(2, 3, 5)
plt.imshow(binary, cmap='gray')
plt.title("Binary Image")
plt.axis('off')

# 显示边缘检测结果
plt.subplot(2, 3, 6)
plt.imshow(image_canny, cmap='gray')
plt.title("Edges")
plt.axis('off')

# 显示子图
plt.tight_layout()
plt.show()
cv2.waitKey(0)
cv2.destroyAllWindows()
